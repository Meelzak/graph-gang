package sample;

import javafx.scene.control.Button;

import java.awt.geom.Point2D;
import java.awt.geom.Point2D.Double;
import java.util.List;
import java.util.ArrayList;

public class Vertices extends Button {

    public ArrayList<Point2D> edges;
    public ArrayList<Button> button;
    public double[] ran = new double[2];


    /**
     * Creates a button with an empty string for its label.
     */
    public ArrayList<Point2D> castList(ArrayList<ArrayList<Integer>> vertice) {
        ArrayList<Point2D> edges = new ArrayList<Point2D>();

        ArrayList<ArrayList<Integer>> main = new ArrayList<>();
        main = vertice;
        ArrayList<Integer> sub = new ArrayList<>();
        int a = 0, b = 0;
        sub.add(1);
        sub.add(2);
        main.add(sub);
        int index = main.size();
        for (int i = 0; i < index; i++) {

            int x;
            for (int y = 0; y < 1; y++) {
                List<Integer> arr = main.get(y);
                int count = 0;
                for (Integer val : arr) {
                    if (count == 0) {
                        a = val;
                        count++;
                    }
                    if (count == 1) {
                        b = val;
                        count = 0;
                    }
                }
            }
            Point2D point = new Point2D.Double(a, b);
            point.setLocation(a, b);
            edges.add(i, point);
        }
        return edges;
    }

    public int getID(Button bt){
        int x = button.indexOf(bt);
        return x;
    }




            //If you want to get values in sub array list








    public double[][] getCoordinates(Point2D dot, int index){
        double[][] vertices = new double[edges.size()][2];
        vertices[index][0] = edges.get(index).getX();
        return vertices;
    }
    public Vertices(int i) {
        //One returns point element
        this.edges = new ArrayList<>();
        //One returns button element
        this.button = new ArrayList<>();
    }


    public ArrayList<Point2D> addVertice(double posX, double posY, int index) {
        Point2D.Double bt = new Point2D.Double(posX, posY);
        edges.add(new Point2D.Double(bt.getX(), bt.getY()));
        return edges;
    }
/*
    public ArrayList<Button> addButtonToo(Button bt, int index) {
        button.add(bt);
        return button;
    }
*/
    public void addButton(Button b, int index) {
        button.add(index, b);
    }

    public Button getButton(int index) {
        return button.get(index);
    }

    public Point2D getPoint(int index) {
        return edges.get(index);
    }


}



