package sample;

public class Line {
}
