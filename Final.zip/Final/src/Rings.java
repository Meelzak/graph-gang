import javax.swing.*;
import java.awt.*;

public class Rings extends JComponent {
    @Override
    public void paintComponent(Graphics graphics){
        Graphics2D g = (Graphics2D) graphics;
        BasicStroke stroke = new BasicStroke(10);
        g.setStroke(stroke);
        g.setColor(Color.BLUE);
       g.drawOval(100,100,100,100);
        g.setColor(Color.BLACK);
        g.drawOval(210,100,100,100);
        g.setColor(Color.RED);
        g.drawOval(320,100,100,100);
        g.setColor(Color.YELLOW);
        g.drawOval(150,150,100,100);
        g.setColor(Color.GREEN);
        g.drawOval(260,150,100,100);


    }
}
