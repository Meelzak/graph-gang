import javax.swing.*;
import java.awt.*;


public class Buttons {
    private static int clickedA=0;
    private static int clickedB=0;
    public static void main(String[] args){
        JFrame jFrame = new JFrame("Buttons");
        JButton button = new JButton("Button A");
        Font font = new Font("Times New Roman",100,100);
        button.setPreferredSize(new Dimension(500,200));
        button.setFont(font);
        JButton button1 = new JButton("Button B");
        button1.setPreferredSize(new Dimension(500,200));
        button1.setFont(font);
        jFrame.add(button);
        jFrame.setSize(2000,1000);
        jFrame.add(button1);
        jFrame.setLayout(new FlowLayout());
        jFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        button.addActionListener(e -> {
            clickedA++;
            System.out.println("Button A was clicked: "+clickedA);
        });
        button1.addActionListener(e -> {
            clickedB++;
            System.out.println("Button B was clicked: "+clickedB);
        });
        jFrame.setVisible(true);


    }
}
