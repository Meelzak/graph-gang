import javax.swing.*;

public class HouseTest {
    public static void main(String[] args){
        JFrame jFrame = new JFrame("House");
        jFrame.setSize(900,900);
        jFrame.add(new HouseDraw());
        jFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        jFrame.setVisible(true);
    }
}
