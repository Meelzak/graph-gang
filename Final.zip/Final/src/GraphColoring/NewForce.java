package GraphColoring;
import java.util.ArrayList;

public class NewForce{
    public int doNewForce(Graph graph,int upperBound,int lowerBound){
        doIt(graph,0,upperBound);
        return upperBound;
    }
    public void doIt(Graph graph,int startDot,int smallesChrom){

    }
}