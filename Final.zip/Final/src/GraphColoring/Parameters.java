package GraphColoring;

public class Parameters {
    public static final double maxPushOf=9;//maximales abstoßen
    public static final double pushOfTo=300;//wie lange es gedrückt wird
    public static final double divideBy=3;//maximaler zug pro rechnung

    public static final double maxPushOfSpring=1.4;
    public static final double pushOfToSpring=100;


    public static final double maxPushOfBorder=25;
    public static final double pushOfToBorder=1000;

}
