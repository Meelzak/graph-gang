import javax.swing.*;
import java.awt.*;

public class HouseDraw extends JComponent {
    @Override
    public void paintComponent(Graphics g){
        g.drawRect(300,500,300,300);
        g.drawRect(500,700,50,100);
        g.drawRect(350,700,50,100);

        g.drawRect(320,625,50,50);
        g.drawRect(390,625,50,50);
        g.drawRect(460,625,50,50);
        g.drawRect(530,625,50,50);

        g.drawRect(320,550,50,50);
        g.drawRect(390,550,50,50);
        g.drawRect(460,550,50,50);
        g.drawRect(530,550,50,50);

        g.drawLine(300,500,450,400);
        g.drawLine(450,400,600,500);

    }
}