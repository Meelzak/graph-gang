import javax.swing.*;

public class RingsTest{
        public static void main(String[] args){
            JFrame jFrame = new JFrame("Rings");
            jFrame.setSize(900,900);
            jFrame.add(new Rings());
            jFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            jFrame.setVisible(true);
        }
}
