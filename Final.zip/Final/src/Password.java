

import javafx.application.Application;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.HBox;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;

import java.io.*;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.Map;

public class Password extends Application {

    private HBox hBox = new HBox();
    private TextField nameTextField = new TextField();
    private TextField passwordTextField = new TextField();
    private Button submit = new Button("Submit");

    private StackPane stackPane = new StackPane();
    private Label label = new Label("Logged In");
    private static Map<String,String> map = new HashMap();
    private int trys=0;

    public static void main(String[] args) {
        try{
            File file = new File(Paths.get("User.txt").toAbsolutePath().toUri());
            BufferedReader reader = new BufferedReader(new FileReader(file));
            String[] strg = reader.readLine().split(" ");
            map.put(strg[0].toUpperCase(),strg[1]);
            launch(args);
        } catch (IOException e){
            e.printStackTrace();
            System.out.println("No UserFile");
            System.exit(0);
        }
    }

    @Override
    public void start(Stage primaryStage) {
        nameTextField.setPromptText("Name");
        passwordTextField.setPromptText("Password");
        submit.setMinSize(nameTextField.getWidth()/2,nameTextField.getHeight());
        hBox.getChildren().addAll(nameTextField,passwordTextField,submit);
        hBox.setAlignment(Pos.CENTER);
        hBox.setSpacing(3.5);
        Scene scene1 = new Scene(hBox,400,300);
        stackPane.getChildren().add(label);
        stackPane.setAlignment(Pos.CENTER);
        Scene scene2 = new Scene(stackPane,400,300);

        submit.addEventHandler(MouseEvent.MOUSE_CLICKED,event -> {
            String n = nameTextField.getText().toUpperCase();
            String p = passwordTextField.getText();
            if(map.containsKey(n)&&map.get(n).equals(p)){
                    primaryStage.setScene(scene2);
            }else{
                if(trys<2){
                    trys++;
                    nameTextField.setText("");
                    passwordTextField.setText("");
                }else{
                    Alert alert = new Alert(Alert.AlertType.ERROR);
                    alert.setTitle("ERROR");
                    alert.showAndWait().ifPresent(e -> {
                        System.exit(0);
                    });
                }
            }

        });

        primaryStage.setTitle("Password");
        primaryStage.setScene(scene1);
        primaryStage.show();
    }
}
