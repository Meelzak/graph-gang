import java.io.File; 
import java.util.Scanner; 

public class ReadFromFile { 
    public static void main(String[] args) {
        // pass the path to the file as a parameter 
       /* File file = new File("test.txt");
        Scanner sc = new Scanner(file); 

        while (sc.hasNextLine()) {
            System.out.println(sc.nextLine()); 
        }
    */
    }
}