

import javafx.application.Application;
import javafx.beans.property.BooleanProperty;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.io.File;
import java.util.ArrayList;

public class Converter extends Application {
    private HBox hBox = new HBox();
    private VBox vBox = new VBox();
    private TextField textField=new TextField();
    private Label label = new Label();
    private ComboBox comboBox = new ComboBox();
    private ComboBox comboBox2 = new ComboBox();
    private ArrayList<String> list = new ArrayList<>();

    public static void main(String[] args){
        launch(args);
    }
    @Override
    public void start(Stage primaryStage) throws Exception {
        vBox.setSpacing(3);
        hBox.setSpacing(3);
        hBox.setAlignment(Pos.CENTER);
        vBox.setAlignment(Pos.CENTER);
        textField.setPromptText("Amount");
        label.setMinSize(textField.getWidth(),textField.getHeight());
        list.add("EUR");
        list.add("USD");
        list.add("GBP");
        comboBox.setItems(FXCollections.observableArrayList(list));
        comboBox.getSelectionModel().select(1);
        comboBox2.setItems(FXCollections.observableArrayList(list));
        comboBox2.getSelectionModel().select(2);
        vBox.getChildren().addAll(textField,label);
        hBox.getChildren().addAll(comboBox,vBox,comboBox2);

        Scene scene = new Scene(hBox,400,300);
        textField.textProperty().addListener((observable, oldValue, newValue) -> {
            setCurrency();
        });
        comboBox.valueProperty().addListener((observable, oldValue, newValue) -> {
            setCurrency();
        });
        comboBox2.valueProperty().addListener((observable, oldValue, newValue) -> {
            setCurrency();
        });

        primaryStage.setTitle("Convert");
        primaryStage.setScene(scene);
        primaryStage.show();

    }
    private void setCurrency(){
        try {
            double d = Double.parseDouble(textField.getText());
            String choosed =(String)comboBox.getSelectionModel().getSelectedItem();
            String choosed2 =(String)comboBox2.getSelectionModel().getSelectedItem();
            Boolean b=false;
            switch (choosed){
                case "EUR": {
                    switch (choosed2){
                        case "USD": d=d*1.18;
                            break;
                        case "GBP": d=d*1/1.12;
                            break;
                        case "EUR":label.setText("Same Currency"); b=true;
                            break;
                    }

                }break;
                case "GBP":{
                    switch (choosed2){
                        case "USD": d=d*1.32;
                            break;
                        case "GBP": label.setText("Same Currency"); b=true;
                            break;
                        case "EUR":d=d*1.12;
                            break;
                    }

                }break;
                case "USD":{
                    switch (choosed2){
                        case "USD": label.setText("Same Currency"); b=true;
                            break;
                        case "GBP": d=d*1/1.32;
                            break;
                        case "EUR":d=d*1/1.18;
                            break;
                    }
                }
            }
            if(!b){
                label.setText(Double.toString(d));
            }
        }catch (NumberFormatException e){
            label.setText("Insert valid number");
        }
    }
}
