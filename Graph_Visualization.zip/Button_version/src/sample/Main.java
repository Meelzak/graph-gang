package sample;

//--I sincerely apologise for having no comments, whatsoever.
//--They will be added is short notice.
//
//   --Have a Chromatic Day!--

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.Event;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.input.DragEvent;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Line;
import javafx.scene.shape.StrokeLineCap;
import javafx.stage.Stage;
import javafx.application.Application;
import javafx.event.EventHandler;
import javafx.scene.Cursor;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.BorderPane;
import javafx.stage.Stage;
import javafx.scene.input.DragEvent;
import javafx.scene.input.*;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.shape.Rectangle;
import javafx.scene.paint.Color;
import javafx.scene.input.*;


import java.util.Random;

public class Main extends Application {
    /*


    ///////////////////////////// R E A D  M E ! ! ! ///////////////////////////
    NOTE:
    If u wanna add array list as graph generation
    use
    vertices.edges.addAll() or the one u add collections
    to define vertices use the castList method to cast lists
    and set edges = castList(YourList(Must be an integer list like [x,y],[x2,y2], etc)

    than disable random button and vertice creation and use the for case for
    drawing vertices as castList.

       button ID returner is still missing, will code a getID method asap. Cheers!
    ----DONT FORGET TO ENTER noEdge noVertice numbers!----

    C ya!
    */
    private Vertices verticies = new Vertices(0);
    Random random = new Random();
    double edgeXValue;
    double edgeYValue;
    int noEdge, count = 0;
    int noVertice;
    boolean isComplete = false;
    Button testButton = new Button();
    double stageX, stageY;

    @Override
    public void start(Stage primaryStage) throws Exception{
        Parent root = FXMLLoader.load(getClass().getResource("sample.fxml"));
        primaryStage.setTitle("Map Visualization");
        primaryStage.setScene(new Scene(root, 800, 600));
        stageX = primaryStage.getWidth();
        stageY = primaryStage.getHeight();
        System.out.println( stageX + " and " + stageY);


        noEdge = 13; //Change no of edges
        noVertice = 20; //Change no of vertices



        Pane ButtonView = (Pane) primaryStage.getScene().lookup("#ButtonView");
        Pane GraphView = (Pane) primaryStage.getScene().lookup("#EdgeView");

       for (int i = 0; i <noEdge; i++) {
           Button button = createButton(i);
           verticies.addVertice(edgeXValue, edgeYValue, i);
           verticies.addButton(button,i);
           // Button controlledButton = controledButton();
           button.addEventHandler(MouseEvent.MOUSE_CLICKED, new EventHandler<MouseEvent>() {
               @Override
               public void handle(MouseEvent e){

                   count++;  /*  for (int index = 0; index < verticies.edges.size(); index++) {
                       int position = -1;
                       if (buttonClicked == verticies.edges.get(index)) {
                           position = index;
                           break;
                       }
                   }*/

                   System.out.println("Button: " + verticies.edges.indexOf(button) + " clicked " + count + " times.");
               }
           });

           ButtonView.getChildren().add(button);
           // else {
           //  ButtonView.getChildren().add(controlledButton);
           // }   //controledButton is for managing how maps will look (still experimental)

           System.out.println("added button");

       }
        isComplete = false;

        for (int i = 1; i <noEdge; i++){
                Line line = createLine(i);
                GraphView.getChildren().add(line);
                isComplete=true;
          }
        if (isComplete){
        for (int i = 0; i <noVertice-noEdge; i++) {
            Line line = randomLine(noEdge);
            GraphView.getChildren().add(line);
        }
        }

        verticies.getCoordinates(verticies.edges.get(2),4);

        primaryStage.show();
    }


    public static void main(String[] args) {
        launch(args);
    }



    public Button createButton(int init){
        Button bt = new Button();
        bt.setShape(new Circle(30));
        bt.setMaxSize(45,45);
        bt.setMinSize(45,45);
        bt.setStyle("-fx-background-image: url('/sample/cat.png'); -fx-background-radius: 300;");
        edgeXValue =  (random.nextDouble() * 740) + 30;
        edgeYValue =  (random.nextDouble() * 560) + 30;
       // (Math.random() * 540 + 40)
       bt.setLayoutX(edgeXValue);
       bt.setLayoutY(edgeYValue);

      //Handle events here!!!
        return bt;
    }

    public Button controledButton(){
        Button bt = new Button();
        bt.setShape(new Circle(30));
        bt.setMaxSize(45,45);
        bt.setMinSize(45,45);
        bt.setStyle("-fx-background-image: url('/sample/cat.png'); -fx-background-radius: 300;");
        double mapXValue = edgeXValue;
        double mapYValue = edgeYValue;
        double temp = random.nextDouble();
        boolean isPos;
        if (temp < 0.5){isPos = true;}else{isPos=false;}
        if (isPos == true){
            edgeXValue =    (mapXValue + (Math.random()* 20));
            edgeYValue =    (mapYValue - (Math.random()* 20));
        } else {
            edgeXValue =    (mapXValue - (Math.random()* 20));
            edgeYValue =    (mapYValue + (Math.random()* 20));
        }
        bt.setLayoutX(edgeXValue);
        bt.setLayoutY(edgeYValue);
        return bt;
    }

    public double edgeMap(double init)  {
        double closeFactor;
        double i = random.nextDouble();
        if (i<0.5){
           closeFactor = (Math.random()*80) + init;
        } else {
            closeFactor = (Math.random()*80) + init;
        }
        return closeFactor;
    }

    public Line createLine(int i){

        Line line = new Line(verticies.getPoint(i).getX()+20, verticies.getPoint(i).getY()+20, verticies.getPoint(i-1).getX()+20, verticies.getPoint(i-1).getY()+20);
        line.setStroke(Color.ORANGE);
        line.setStrokeWidth(1.2);
        line.setStrokeLineCap(StrokeLineCap.ROUND);
        return line;
    }

    public Line randomLine(int length){
        int ran1 = (int) (Math.random()* (length));
        int ran2 = (int) (Math.random()* (length));
        if (isComplete==false){
        verticies.ran[0]=ran1;
        verticies.ran[1]=ran2;} else {
            if (verticies.ran[0] == ran1 && verticies.ran[1] == ran2){
                ran1 =  ran(length);
                ran2 = ran(length);
            }
        }
        Line line = new Line((verticies.getPoint(ran1).getX() + 20), verticies.getPoint(ran1).getY() + 20,verticies.getPoint(ran2).getX()+ 20,(verticies.getPoint(ran2).getY())+ 20);
        line.setStroke(Color.ORANGE);
        line.setStrokeWidth(1.7);
        line.setStrokeLineCap(StrokeLineCap.ROUND);
        isComplete =true;
        return line;
    }
//Extra
    public int ran(int length){
       int i =  (int) (Math.random()* (length-1));
       return i;
    }
    public void handleButtonAction( ActionEvent event ) {
        // Button was clicked, do something…
        count++;
        System.out.println("Button Clicked " + count + " times.");
    }
}


